<?php
declare(strict_types=1);

// Update these for your XAMPP/MySQL.
const DB_HOST = '127.0.0.1';
const DB_NAME = 'ldo';
const DB_USER = 'root';
const DB_PASS = '';
const DB_CHARSET = 'utf8mb4';

// When true, password reset will show a link on-screen (no email sending yet).
const DEV_SHOW_RESET_LINK = true;
